<!-- Modal -->
<div class="modal fade" id="cadastrarVacinacaoAtendimentosModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Cadastrar Vacinação</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?= BASE_URL ?>/vacinacao/CriarVacinacao">
                    <!-- ID DO AGENDAMENTO -->
                    <input type="hidden" name="id_agend_vac_atend_modal" id="id_agend_vac_atend_modal">
                    <!-- CLIENTE -->
                    <div class="mb-3">
                        <label for="cliente_id_fk_vacinacao" class="form-label">Cliente (Dono)</label>
                        <input class="form-control" disabled type="text" name="cliente_nome_vac_atend_modal" id="cliente_nome_vac_atend_modal">
                        <input type="hidden" name="id_cliente_vacinacao" id="cliente_id_vac_atend_modal">
                    </div>
                    <!-- PET -->
                    <div class="mb-3">
                        <label for="pet_id_fk_vacinacao" class="form-label">Pet</label>
                        <input class="form-control" disabled type="text" name="pet_nome_vac_atend_modal" id="pet_nome_vac_atend_modal">
                        <input type="hidden" name="id_pet_vacinacao" id="pet_id_vac_atend_modal">
                    </div>

                    <!-- VETERINARIO (VACINA) -->
                    <div class="mb-3">
                        <label for="proxima_dose" class="form-label">Veterinario</label>
                        <input disabled type="text" class="form-control" id="vet_login_vac_atend_modal">
                        <input type="hidden" name="id_vet_vacinacao" class="form-control" id="vet_id_vac_atend_modal">
                    </div>

                    <!-- VACINAS -->
                    <div class="mb-3" id="container_select_vacina">
                        <label for="vet_login_vac_atend_modal" class="form-label">Vacinas</label>
                        <select name="id_vacina_servico" id="select_vac_atend_modal" class="form-select">
                            <option value="" selected>Selecionar</option>
                            <?php foreach ($vacinas as $vac) { ?>
                                <option value="<?= $vac['id_servico'] ?>"><?= $vac['nome_servico'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3" id="container_input_vacina">
                        <label for="id_vacina_servico" class="form-label">Vacina</label>
                        <input disabled class="form-control" type="text" id="nome_vac_atend_modal">
                        <input type="hidden" name="id_vacina_servico" id="id_vac_atend_modal">
                    </div>

                    <!-- DATA APLICAÇÃO -->
                    <div class="mb-3">
                        <label for="data_aplicacao" class="form-label">Data de Aplicação</label>
                        <input type="date" name="data_aplicacao" class="form-control" id="data_aplicacao">
                    </div>
                    <!-- DATA PROX DOSE -->
                    <div class="mb-3">
                        <label for="proxima_dose" class="form-label">Data de Prox. Dose</label>
                        <input type="date" name="data_prox_dose" class="form-control" id="proxima_dose">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">Criar</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>