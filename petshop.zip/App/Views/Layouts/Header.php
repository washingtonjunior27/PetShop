<?php
date_default_timezone_set("America/Manaus");
$hojeData = date("d/m/Y");
$hojeDiaSemana = date("l");

switch ($hojeDiaSemana) {
    case "Monday":
        $diaSemana = "Segunda-Feira";
        break;
    case "Tuesday":
        $diaSemana = "Terça-Feira";
        break;
    case "Wednesday":
        $diaSemana = "Quarta-Feira";
        break;
    case "Thursday":
        $diaSemana = "Quinta-Feira";
        break;
    case "Friday":
        $diaSemana = "Sexta-Feira";
        break;
    case "Saturday":
        $diaSemana = "Sábado";
        break;
    case "Sunday":
        $diaSemana = "Domingo";
        break;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Petshop</title>
    <link rel="stylesheet" href="/petshop/public/Assets/css/styles.css">
    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- GOOGLE FONTS POPPINS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css"
        integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

    <div class="container-fluid home-bg">
        <div class="row min-vh-100">
            <div id="sidenav-section" class="col-md-2 main-bg position-sticky top-0 p-0 d-none d-md-flex flex-column border-light border-5 border-end vh-100">
                <!-- LOGO -->
                <a href="<?= BASE_URL ?>/home" class="nav-link d-flex justify-content-center gap-1 p-4 border-5 border-white border-bottom">
                    <i class="fa-solid fa-paw fs-2 text-light"></i>
                    <h4 class="fs-2 text-light">PetShop</h4>
                </a>

                <!-- SIDENAV -->
                <div class="mt-4 d-flex flex-column gap-3 flex-grow-1" id="sidenavAccordion">
                    <?php
                    $sidenavParent = "sidenavAccordion";
                    require __DIR__ . "/Sidenav.php";
                    ?>
                </div>

                <!-- LOGOUT -->
                <div class="w-100 border-5 border-top border-light mb-4">
                    <a href="<?= BASE_URL ?>/logout" class="sidenav-item w-100 nav-link d-flex align-items-center justify-content-center gap-2 mt-4" style="padding: 10px 0;">
                        <i class="fa-solid fa-arrow-right-from-bracket text-light fs-4"></i>
                        <span class="text-light fs-6 fw-semibold">Logout</span>
                    </a>
                </div>

            </div>

            <div class="col-md-10 p-0 flex-grow-1" id="content-section">
                <nav class="navbar navbar-expand-md navbar-dark main-bg py-3 px-4" style="height: 80px;">
                    <div class="d-flex justify-content-between align-items-center flex-fill">
                        <h2 class="fs-6 text-light mb-0 d-none d-md-flex">Olá, <?= $user['usuario']['login'] ?> 👋 | <?= $hojeData, " " . $diaSemana . " | " . $user['usuario']['role'] ?>
                        </h2>
                        <button class="navbar-toggler d-md-none" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#sidebarMenu">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="text-white gap-2">
                            <a href="#" class="nav-link d-flex gap-2">
                                <span><?= $user['usuario']['login'] ?></span>
                                <i class="fa-solid fa-user fs-4"></i>
                            </a>
                        </div>
                    </div>
                </nav>