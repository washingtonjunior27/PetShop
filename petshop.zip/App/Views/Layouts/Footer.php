</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="/petshop/public/Assets/scripts/script.js"></script>
<script src="/petshop/public/Assets/scripts/funcionarios.js"></script>
<script src="/petshop/public/Assets/scripts/clientes.js"></script>
<script src="/petshop/public/Assets/scripts/veterinarios.js"></script>
<script src="/petshop/public/Assets/scripts/especies.js"></script>
<script src="/petshop/public/Assets/scripts/racas.js"></script>
<script src="/petshop/public/Assets/scripts/servicos.js"></script>
<script src="/petshop/public/Assets/scripts/pets.js"></script>
<script src="/petshop/public/Assets/scripts/agendamentos.js"></script>
<script src="/petshop/public/Assets/scripts/meusServicos.js"></script>
<script src="/petshop/public/Assets/scripts/atendimentos.js"></script>
<script src="/petshop/public/Assets/scripts/vacinacao.js"></script>
<script src="/petshop/public/Assets/scripts/lembretes.js"></script>

</body>

</html>