<?php

require_once __DIR__ . "/../vendor/autoload.php";


use App\Config\Connection;

$conn = new Connection();
$pdo = $conn->getConn();

$senha = "123456";

$password = password_hash($senha, PASSWORD_ARGON2ID);

$sql = "INSERT INTO usuarios (nome, login, email, senha, telefone, role, status, primeiro_acesso)
        VALUES (:nome, :login, :email, :senha, :telefone, :role, :status, :primeiro_acesso)";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':nome' => 'admin',
    ':login' => 'admin',
    ':email' => 'washjunior4444@gmail.com',
    ':senha' => $password,
    ':telefone' => '92981599075',
    ':role' => 'Admin',
    ':status' => 'Ativo',
    ':primeiro_acesso' => 1
]);
